Java SE Platform - JDK 14.
The basis of the game was taken from open sources (http://zetcode.com/tutorials/javagamestutorial/tetris/ for the Tetris class and GameField class and https://habr.com/ru/post/191422/ for the Sound class) and modified. Were added:

- new figures;
- reflection button;
- mute button;
- preview field;
- Homer Simpson figure and his actions (walking, teleportation, take-off, death) and sounds;
- other small details.

Control keys: right, left, up (turn), space (drop), D (accelerate the fall), E (change the direction of rotation), R (flip horizontally), P (pause).