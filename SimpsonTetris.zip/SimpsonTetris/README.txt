Java SE Platform - JDK 14.
The basis of the game was taken from open sources (http://zetcode.com/tutorials/javagamestutorial/tetris/ for the Tetris class and GameField class and https://habr.com/ru/post/191422/ for the Sound class) and modified. Were added:

- new figures;
- reflection button (appears after 20 removed lines);
- mute button;
- preview field (appears after 30 removed lines);
- Homer Simpson figure and his actions (walking, teleportation, take-off, death) and sounds;
- other small details.

Control keys: Right, Left, Up (turn), Space (drop), D (accelerate the fall), E (change the direction of rotation), R (flip horizontally, appears after 20 removed lines), P (pause).